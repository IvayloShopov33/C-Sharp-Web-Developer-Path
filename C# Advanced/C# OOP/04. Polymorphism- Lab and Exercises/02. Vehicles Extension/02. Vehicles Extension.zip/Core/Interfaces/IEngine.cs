﻿namespace VehiclesExtension.Core.Interfaces
{
    internal interface IEngine
    {
        void Run();
    }
}
