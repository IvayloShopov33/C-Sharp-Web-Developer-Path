﻿namespace Operations.Core.Interfaces
{
    public interface IEngine
    {
        void Run();
    }
}
