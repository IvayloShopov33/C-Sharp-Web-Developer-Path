﻿using Raiding.IO.Interfaces;

namespace Raiding.IO
{
    public class Reader : IReader
    {
        public string ReadLine() => Console.ReadLine();
    }
}
