﻿using WildFarm.Models.Foods;

namespace Wil_Farm.Models.Foods
{
    public class Vegetable : Food
    {
        public Vegetable(int quantity)
            : base(quantity)
        {

        }
    }
}
