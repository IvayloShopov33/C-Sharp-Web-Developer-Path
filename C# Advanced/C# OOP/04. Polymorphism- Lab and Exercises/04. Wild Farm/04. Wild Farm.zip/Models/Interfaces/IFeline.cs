﻿namespace WildFarm.Models.Interfaces
{
    public interface IFeline : IAnimal
    {
        string Breed { get; }
    }
}
