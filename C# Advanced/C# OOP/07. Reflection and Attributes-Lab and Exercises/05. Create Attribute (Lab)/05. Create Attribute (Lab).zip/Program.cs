﻿namespace AuthorProblem
{
    [Author("Alexander")]
    public class StartUp
    {
        [Author("John")]
        static void Main(string[] args)
        {
        }
    }
}