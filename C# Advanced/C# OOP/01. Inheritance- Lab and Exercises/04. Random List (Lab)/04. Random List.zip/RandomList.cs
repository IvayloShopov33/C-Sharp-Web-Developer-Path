﻿namespace CustomRandomList
{
    public class RandomList : List<string>
    {
        private Random random;

        public RandomList()
        {
            this.random = new Random();
        }

        public string RandomString()
        {
            int randomIndex = random.Next(0, base.Count);
            string element = base[randomIndex];
            base.RemoveAt(randomIndex);

            return element;
        }
    }
}
