﻿namespace BirthdayCelebrations.Core.Interfaces
{
    public interface IEngine
    {
        void Run();
    }
}
