﻿namespace BorderControl.Models.Interfaces
{
    public interface IIdentification
    {
        string Id {  get; }
    }
}
